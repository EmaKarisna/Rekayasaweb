<?php 
if(@get(1)!="")
{            
       if(@get(1)=="hklinen"){$cat = "HK Linen";}
       elseif(@get(1)=="fblinen"){$cat = "FB Linen";}
       elseif(@get(1)=="amenities"){$cat = "Amenities";}
       elseif(@get(1)=="towel"){$cat = "Towel";}
       elseif(@get(1)=="slipper"){$cat = "Slipper";}
       
	$param = " AND  kategori = '".@$cat."'";
}

{
?>

		
		<h2><?php echo $data['judul'];?></h2>  
          <div class="clr"></div>
          <div class="img"><img src="upload/<?php echo $data['foto'];?>" width="338" alt="" class="fl" /></div>
          <div class="post_content">
            <p>
            <?php echo $data['konten'];?>
            </p>
            
          </div>
          
          <div class="clr"></div>
    <?php } ?>
       

