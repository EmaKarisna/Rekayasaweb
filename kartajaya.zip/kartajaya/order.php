<?php 
if(@get(1)!="")
{
	$param = "AND judul = '".get(1)."'";
}

?>
					<td class="Thead" width="50px">No.</td>  
					<td class="Thead" width="250px">Jenis paket</td>
					<td class="Thead" width="250px">Jumlah armada</td>
					<td class="Thead" width="100px">Tanggal pesan</td>
					<td class="Thead" width="300px">Nama</td>
					<td class="Thead" width="250px">Hp</td>
					<td class="Thead" width="100px">E-mail</td>
					<td class="Thead" width="160px">Dp</td>
					<td class="Thead" width="100px">BANK</td>
					<td class="Thead" width="100px">Atas nama</td>
					<td class="Thead" width="100px">Pesan</td>
					<td class="Thead" width="100px">Keterangan</td>
					<td class="Thead" width="160px">Option</td>
				</tr>
?>

