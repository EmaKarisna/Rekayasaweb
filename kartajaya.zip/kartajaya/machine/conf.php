<?php
function page()
{
	return "http://localhost/kartajaya/";
}
//GET CURENT URL
function curPageURL() {
$pageURL = 'http';
if (@$_SERVER["HTTPS"] == "on") {$pageURL .= "s";}
$pageURL .= "://";
if (@$_SERVER["SERVER_PORT"] != "80") {
  $pageURL .= $_SERVER["SERVER_NAME"].":".$_SERVER["SERVER_PORT"].$_SERVER["REQUEST_URI"];
} else {
  $pageURL .= $_SERVER["SERVER_NAME"].$_SERVER["REQUEST_URI"];
}
return $pageURL;
} 

//GET CURENT URL PAGE NAME
function curPageName() {
return substr($_SERVER["SCRIPT_NAME"],strrpos($_SERVER["SCRIPT_NAME"],"/")+1);
}

//INDEX LOAD
function index($filename)
{ 
	$x = 0;
	$url = str_replace(page(),"",curPageURL());
	$url = str_replace(".nz","",$url);
	$sub_url = explode("/",@$url);
	if(@$sub_url[0]=="")
	{
		$status = @include("controller/".$filename);
		if (!$status)
		{
			echo "<style>body{background-color:#808080;}</style><br><br><br><div align='center'><img src='".page()."lib/images/404.jpg'</div>";
		}
	}
	else
	{
		$status = @include("controller/".$sub_url[0].".php");
		if (!$status)
		{
			echo "<style>body{background-color:#808080;}</style><br<br><br><div align='center'><img src='".page()."lib/images/404.jpg'</div>";
			
		}
	}
	

	
}

function get($i)
{
$url = str_replace(page(),"",curPageURL());
$url = str_replace(".nz","",$url);
$sub_url = explode("/",@$url);
return $sub_url[$i];	
}

function getTemplate($html)
{
ob_start();
include_once( 'html/'.$html.".html" );
$html = ob_get_contents();
ob_end_clean(); 
$html = str_replace('[url]',page(),$html);
return $html;
}

function timePlusPlus($datetime,$jam_plus,$menit_plus,$detik_plus,$bulan_plus,$hari_plus,$tahun_plus)
{
$tanggal = explode("-",substr($datetime,0,10));
$thn = $tanggal[0];
$bln = $tanggal[1];
$tgl= $tanggal[2];
$waktu = explode(":",substr($datetime,11,8));
$jam = $waktu[0];
$menit = $waktu[1];
$detik= $waktu[2];
//return $thn."#".$bln."#".$tgl."#".$jam."#".$menit."#".$detik;
$hasil = mktime($jam + $jam_plus,$menit + $menit_plus,$detik + $detik_plus,$tgl + $hari_plus,$bln + $bulan_plus,$thn + $tahun_plus);
$hasilx = date("Y-m-d H:i:s", $hasil);
return $hasilx;
}

function tanggalindo($mentah) {
$pecah = explode("-",$mentah);
$tanggal = $pecah[2]."/".$pecah[1]."/".$pecah[0];
return $tanggal;
}
function indotosql($mentah) {
$pecah = explode("/",$mentah);
$tanggal = $pecah[2]."-".$pecah[0]."-".$pecah[1];
return $tanggal;
}

function redirect($url)
{
	echo '<script>window.location = "'.$url.'"</script>';	
}

if(substr(curPageURL(),"0","10") == "http://www")
{
	redirect(str_replace("www.","",curPageURL()));
}

function getNumbSQL($query)
{
	$proses = mysql_query($query);
	$numb = mysql_num_rows($proses);
	return $numb;
}

function getSQL($query)
{
	$proses = mysql_query($query);
	$SQLarray = mysql_fetch_array($proses);
	return $SQLarray;
}

function timeNow()
{
return date("Y-m-d h:i:s");	
}

function slug($title)
{
	return strtolower(str_replace(" ","-",$title));
}
function post($variable)
{
return $_POST[$variable];
}
?>
