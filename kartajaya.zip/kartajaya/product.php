<?php 
if(@get(1)!="")
{

	$param = " AND  judul = '".get(1)."'";
}

{
?>

		<h2>PRODUCT</h2>  
          <div class="img"><img src="upload/<?php echo $data['foto'];?>" width="300" alt="" class="fl" /></div>
          
          <div class="clr"></div>
    <?php } ?>
       

