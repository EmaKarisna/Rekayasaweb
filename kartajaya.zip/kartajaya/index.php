<?php 
session_start();
include "machine/conf.php";

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Ema</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="css/style.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" type="text/css" href="css/coin-slider.css" />
<script type="text/javascript" src="js/cufon-yui.js"></script>
<script type="text/javascript" src="js/cufon-titillium-250.js"></script>
<script type="text/javascript" src="js/jquery-1.4.2.min.js"></script>
<script type="text/javascript" src="js/script.js"></script>
<script type="text/javascript" src="js/coin-slider.min.js"></script>
</head>
<body>
<div class="main">
  <div class="header">
    <div class="header_resize">
      <div class="menu_nav">
        <ul>
          <li><a href="<?php echo page()?>?home"><span>Home</span></a></li>
          <li><a href="<?php echo page()?>?profile"><span>Profile</span></a></li>
          <li><a href="<?php echo page()?>?product"><span>Product</span></a></li>
          <li><a href="<?php echo page()?>?contact"><span>Contact</span></a></li>
          <li><a href="<?php echo page()?>?order"><span>order</span></a></li>
        </ul>
      </div>
      <div class="logo">
        <h1><a href="index.html">KARTA JAYA</span> <small>Distributor Perlenkapan Hotel</small></a></h1>
      </div>
      <div class="clr"></div>
      <div class="slider">
        <div id="coin-slider"> <a href="#"><img src="images/slidea.jpg" width="910" height="340" alt="" /> </a> <a href="#"><img src="images/slideb.jpg" width="910" height="340" alt="" /> </a> <a href="#"><img src="images/slidec.jpg" width="910" height="340" alt="" /> </a> </div>
        <div class="clr"></div>
      </div>
      <div class="clr"></div>
    </div>
  </div>
  <div class="content">
    <div class="content_resize">
      <div class="mainbar">
		  <div class="article">
        
			<?php 
			if(@get(0)!="")
			{
				$include = str_replace("?", "", @get(0));
				include "".$include.".php";
			}
		else {
			//DEFAULT PAGE
			echo "<script>window.location = '?page';</script>";
		
		}
			?>
          
          <div class="clr"></div>
        </div>
        
      </div>
      <div class="sidebar">
        <div class="gadget">
          <h2 class="star"><span>Categori</span></h2>
          <div class="clr"></div>
          <ul class="sb_menu">
			  
            <li><a href="<?php echo page();?>?categori/hklinen">HK Linen</a></li>
			<li><a href="<?php echo page();?>?categori/fblinen">FB Linen</a></li>
            <li><a href="<?php echo page();?>?categori/amenities">Amenities</a></li>
            <li><a href="<?php echo page();?>?categori/towel">Towel</a></li>
            <li><a href="<?php echo page();?>?categori/plastik">Plastik</a></li>
            <li><a href="<?php echo page();?>?categori/slipper">Slipper</a></li>
            
          </ul>
        </div>
        <div class="gadget">
          <h2 class="star"><span>Promo</span></h2>
          <div class="clr"></div>
          <ul class="ex_menu">
           <ul>
        </div>
      </div>
      <div class="clr"></div>
    </div>
  </div>
  
  <div class="footer">
    <div class="footer_resize">
      <p class="lf">&copy; Copyright <a href="#">www.KartaJaya.com</a>.</p>
      <p class="rf">Design by <a href="http://www.KarisnaSK.com/">KarisnaSK</a></p>
      <div style="clear:both;"></div>
    </div>
  </div>
</div>
</body>
</html>

